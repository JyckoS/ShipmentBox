package com.gmail.JyckoSianjaya.ShipmentBox.Utils;

public class SBEnum {
	public enum InventoryType {
		Menu,
		AccessMenu,
		BoxMenu;
	}
	public enum MenuAction {
		Teleport,
		Access,
		Time,
		Status;
	}
	public enum AccessAction {
		Previous,
		Next,
		MainMenu,
		ClickHead,
	}
	public enum Message {
		Died("I am a godless heathen and I approved this message");
		private String message;
		Message(String str) {
			this.message = Utility.TransColor(str);
		}
	}
}
