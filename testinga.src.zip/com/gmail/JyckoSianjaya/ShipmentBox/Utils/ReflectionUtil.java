package com.gmail.JyckoSianjaya.ShipmentBox.Utils;

import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.validation.Validator;



public class ReflectionUtil {
	public static Field getField(final Class<?> clazz, final String name)
	{
	    try
	    {
	        Field f = clazz.getDeclaredField(name);
	        f.setAccessible(true);
	        return f;
	    }
	    catch(NoSuchFieldException | SecurityException ex)
	    {
	        throw new NullPointerException("Field " + name + " does not exist in class " + clazz.getName());
	    }
	}

	public static Object validateField(final Field f, final Object instance)
	{
	    try
	    {
	        f.isAccessible();
	        return f.get(instance);
	    }
	    catch(IllegalAccessException | IllegalArgumentException ex)
	    {
	        Logger.getLogger(Validator.class.getName()).log(Level.SEVERE, null, ex);
	        return null;
	    }
	}

}
