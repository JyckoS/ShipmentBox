package com.gmail.JyckoSianjaya.ShipmentBox.Utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.gmail.JyckoSianjaya.ShipmentBox.Objects.AccessHolder;
import com.gmail.JyckoSianjaya.ShipmentBox.Objects.TheBox;

public class AccessMenu  {
	private OfflinePlayer owner;
	private List<UUID> trustees;
	private TheBox box;
	private Storage storage = Storage.getInstance();
	private HashMap<Integer, Inventory> page = new HashMap<Integer, Inventory>();
	private HashMap<ItemStack, UUID> owners = new HashMap<ItemStack, UUID>();
	public AccessMenu(Player target) {
		this.owner = target;
		this.box = storage.getBox(owner.getUniqueId());
		this.InitializeInventory();
		storage.setAccessMenu(target.getUniqueId(), this);
	}
	public Inventory getInventory(int page) {
		return this.page.get(page);
	}
	public void removeOwner(ItemStack item) {
		owners.remove(item);
	}
	public ItemStack getKey(UUID uuid) {
		for (ItemStack item : owners.keySet()) {
			if (owners.get(item) == uuid) {
				return item;
			}
		}
		return null;
	}
	public Integer getKeyInventory(Inventory inv) {
		for (int cpage : page.keySet()) {
			if (page.get(cpage) == inv) {
				return cpage;
			}
		}
		return null;
	}
	public UUID getOwner(ItemStack item) {
		return owners.get(item);
	}
	 public static int getMax(Set<Integer> keys){
		 ArrayList<Integer> arrays = new ArrayList<Integer>(keys);
		    int maxValue = arrays.get(0);
		    for(int i=1;i < arrays.size();i++){ 
		      if(arrays.get(i) > maxValue){ 
		         maxValue = arrays.get(i); 
		      } 
		    } 
		    return maxValue; 
		  }
	public void AddPerson(UUID uuid) {
		OfflinePlayer p = Bukkit.getOfflinePlayer(uuid);
		ItemStack item = storage.getHead(p);
		owners.put(item, uuid);
		int max = getMax(page.keySet());
		Inventory inv = page.get(max);
		inv.addItem(item);
		owners.put(item, uuid);
	}
	public void removePerson(UUID uuid) {
		ItemStack item = getKey(uuid);
		owners.remove(item);
		Collection<Inventory> inventory = page.values();
		for (Inventory inv : inventory) {
			if (inv.contains(item)) {
				inv.remove(item);
			}
			int totalitem = 0;
			for (ItemStack iteme : inv.getStorageContents()) {
				totalitem++;
			}
			if (storage.getAccessTotalItems() <= totalitem) {
				int cpage = getKeyInventory(inv);
				inv.clear();
				page.remove(cpage);
			}
		}
	}
	private void InitializeInventory() {
		int maxhead = storage.getMaxHeads();
		int maxpage = Math.max(1, (trustees.size() % maxhead  == 0 ? 1 : trustees.size() / maxhead + 1));
		for (int i = 1; i < maxpage; i++) {
		Inventory inv = Bukkit.createInventory(new AccessHolder(i, this), storage.getAccessMenuSize(), storage.getAccessMenuName());
		Set<Integer> keys = storage.getAccessKeys();
		for (int ee : keys) {
			inv.setItem(ee, storage.getAccessItem(ee));
		}
		List<UUID> trust = box.getAccessed();
		if (trust == null) {
			return;
		}
		int leftover = trust.size();
		while (leftover > maxhead) {
			leftover-=maxhead;
		}
		if (i == maxpage) {
			trust.subList(trust.size() - leftover, trust.size());
		}
		if (i > 1 && i < maxpage) {
			trust.subList(maxhead * (i - 1) + 1, maxhead * (i + 1));
		}
		for (UUID uuid : trust) {
			OfflinePlayer p = Bukkit.getOfflinePlayer(uuid);
			ItemStack item = storage.getHead(p);
			inv.addItem(item);
			owners.put(item, p.getUniqueId());
		}
		page.put(i, inv);
		}
	}
}
