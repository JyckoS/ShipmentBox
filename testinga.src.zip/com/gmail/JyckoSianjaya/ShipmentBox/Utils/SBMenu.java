package com.gmail.JyckoSianjaya.ShipmentBox.Utils;

import javax.swing.Box;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.gmail.JyckoSianjaya.ShipmentBox.Objects.MenuHolder;
import com.gmail.JyckoSianjaya.ShipmentBox.Objects.TheBox;
import com.gmail.JyckoSianjaya.ShipmentBox.Utils.SBEnum.InventoryType;

public class SBMenu extends testclass {
	private static SBMenu instance;
	private final Storage storages = Storage.getInstance();
	private ItemStack CLOCKITEM;
	private ItemStack STATUSITEM;
	private ItemStack ACCESSITEM;
	private ItemStack TELEPORTITEM;
	private int size;
	private static String GUINAME;
	private static Inventory SBMENU;
	private SBMenu() {
		LoadVars();
		LoadMenu();
	}
	public static void OpenMenu(Player p) {
		p.openInventory(SBMENU);
	}
	public static boolean isSBMenu(Inventory inv) {
		return inv.getTitle().equals(GUINAME);
	}
	public static SBMenu getInstance() {
		if (instance == null) {
			instance = new SBMenu();
		}
		return instance;
	}
	private void LoadVars() {
		GUINAME = storages.Menu_getGUIName();
		size = storages.Menu_getSize();
		
		CLOCKITEM = storages.Menu_getTimeItem();
		STATUSITEM = storages.Menu_getStatusItem();
		ACCESSITEM = storages.Menu_getAccessItem();
		TELEPORTITEM = storages.Menu_getTeleportItem();	
	}
	private void LoadMenu() {
		SBMENU = Bukkit.createInventory(new MenuHolder(InventoryType.Menu), size, GUINAME);
		for (int slot : storages.Menu_getKeys()) {
			ItemStack item = storages.getMenuItem(slot);
			SBMENU.setItem(slot, item);
		}
	}
}
