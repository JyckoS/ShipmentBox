package com.gmail.JyckoSianjaya.ShipmentBox.Objects;

import org.bukkit.inventory.Inventory;

import org.bukkit.inventory.InventoryHolder;

import com.gmail.JyckoSianjaya.ShipmentBox.Utils.AccessMenu;

public class AccessHolder implements InventoryHolder {
	private int page;
	private AccessMenu menu;
	public AccessHolder(int page, AccessMenu menu) {
		this.page = page;
		this.menu = menu;
	}
	@Override
	public Inventory getInventory() {
		// TODO Auto-generated method stub
		return null;
	}
	public int getPage() {
		return this.page;
	}
	public AccessMenu getAccessMenu() {
		return this.menu;
	}
}
