package com.gmail.JyckoSianjaya.ShipmentBox.Objects;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import com.gmail.JyckoSianjaya.ShipmentBox.Utils.SBEnum.InventoryType;

public class MenuHolder implements InventoryHolder {
	private InventoryType type;
	public MenuHolder(InventoryType type) {
		this.type = type;
	}
	@Override
	public Inventory getInventory() {
		// TODO Auto-generated method stub
		return null;
	}
	public InventoryType getType() {
		return this.type;
	}
	public Boolean isEqual(InventoryType type) {
		return this.type != type;
	}
}
